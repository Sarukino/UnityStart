# UnityStart

Mappa rendszer hozzáadva

## Game OBjects
- 2 Plane (játéktér hozzáadva)
- Gate hozzáadva
- Player object hozzáadva
- 1 Pick up

## Materials
- Background hozzáadva
- Player
- Gate

## Prefabs

## Scripts
- CameraMove
- PlayerMove
