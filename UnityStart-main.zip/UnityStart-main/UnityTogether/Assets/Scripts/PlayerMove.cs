﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMove : MonoBehaviour
{

    public float moveSpeed;
    private int count;
    private Rigidbody Rb;
    public bool hasAkey;
    public GameObject Key;
    public Text countText;
    public Text WinText;

    // Use this for initialization
    void Start()
    {
        SetCountText();
        count = 0;
        Rb = GetComponent<Rigidbody>();
        moveSpeed = 10f;
        Key.gameObject.SetActive(false);
        WinText.text = "";
        hasAkey = false;
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count++;
            SetCountText();

        }
        else if (other.gameObject.CompareTag("Key"))
        {
            other.gameObject.SetActive(false);
            hasAkey = true;
        }
    }
    void SetCountText()
    {
        countText.text = "Count " + count.ToString();
        if (count == 6)
        {
            Key.gameObject.SetActive(true);
        }
        if (count == 10)
        {
            WinText.text = "YOU WIN!";
        }
    }


    void FixedUpdate()
    {
        transform.Translate(moveSpeed * Input.GetAxis("Horizontal") * Time.deltaTime, 0f, moveSpeed * Input.GetAxis("Vertical") * Time.deltaTime);
    }
}